import paho.mqtt.publish as publish
import json

topic = "pot"
valor_pot = 23
mensaje= {
"timestamp": "00:00",
"value": valor_pot,
}
mensaje_json= json.dumps(mensaje)
hostname = "LAPTOP-EM4849EG" 
publish.single(topic=topic, payload=mensaje_json, qos=1, hostname=hostname,keepalive=60)
print("Pub done") 