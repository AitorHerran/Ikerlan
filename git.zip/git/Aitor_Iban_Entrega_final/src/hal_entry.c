#include "hal_data.h" // Incluye las definiciones y funciones específicas del HAL (Hardware Abstraction Layer)
#include "r_adc_api.h" // Incluye las definiciones y funciones para el módulo ADC (Analog to Digital Converter)
#include "r_iic_master.h" // Incluye las definiciones y funciones para el módulo IIC Master (Inter-Integrated Circuit)
#include "display.h" // Incluye funciones y definiciones relacionadas con la visualización (display)
#include "adc.h" // Incluye funciones y definiciones específicas para el ADC
#include <stdio.h> // Incluye funciones estándar de entrada/salida
#include <stdint.h> // Incluye definiciones de tipos de datos enteros de tamaño específico

// Variables globales
volatile bool pulsador = false; // Variable para el estado del pulsador (botón), 'volatile' indica que puede cambiar en cualquier momento

// Definiciones de arrays para configuración o comunicación
uint8_t f1[0x02] = {0x00, 0x80};
uint8_t f2[0x02] = {0x00, 0xC0};

// Estado del sistema
volatile bool system_on = false; // Indica si el sistema está encendido o no
fsp_err_t icu_init(void); // Declaración de función para inicializar ICU
fsp_err_t icu_enable(void); // Declaración de función para habilitar ICU
void icu_deinit(void); // Declaración de función para deshabilitar ICU

// Más definiciones de arrays
uint8_t m1[0x08] = {0x40, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80};
uint8_t m2[0x08] = {0x40, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80};

// Definición del tamaño del filtro y su implementación
#define FILTRO_TAMANO 5
uint16_t filtro[FILTRO_TAMANO];
uint8_t indiceFiltro = 0;

// Función para actualizar el filtro
void actualizarFiltro(uint16_t nuevaLectura) {
    filtro[indiceFiltro] = nuevaLectura;
    indiceFiltro = (indiceFiltro + 1) % FILTRO_TAMANO;
}

// Función para calcular la mediana del filtro
uint16_t calcularMediana() {
    uint16_t valoresOrdenados[FILTRO_TAMANO];
    memcpy(valoresOrdenados, filtro, sizeof(filtro));

    // Ordenamiento simple del array
    for (int i = 0; i < FILTRO_TAMANO - 1; i++) {
        for (int j = i + 1; j < FILTRO_TAMANO; j++) {
            if (valoresOrdenados[j] < valoresOrdenados[i]) {
                uint16_t temp = valoresOrdenados[i];
                valoresOrdenados[i] = valoresOrdenados[j];
                valoresOrdenados[j] = temp;
            }
        }
    }

    // Retorna el valor mediano
    return valoresOrdenados[FILTRO_TAMANO / 2];
}

// Función para inicializar el LED
void init_led(void) {
    // Configuración del puerto del LED y manejo de errores
    fsp_err_t err = R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);
    assert(FSP_SUCCESS == err);

    err = R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, IOPORT_CFG_PORT_DIRECTION_OUTPUT);
    assert(FSP_SUCCESS == err);
}

// Función para hacer parpadear el LED
void blink_led(void) {
    fsp_err_t err;

    // Encender el LED
    err = R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, BSP_IO_LEVEL_HIGH);
    assert(FSP_SUCCESS == err);

    // Espera
    R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);

    // Apagar el LED
    err = R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_06, BSP_IO_LEVEL_LOW);
    assert(FSP_SUCCESS == err);

    // Espera
    R_BSP_SoftwareDelay(2000, BSP_DELAY_UNITS_MILLISECONDS);
}

// Función para inicializar el pulsador (botón)
void init_pulsador(void) {
    fsp_err_t err;

    // Configuración de interrupción externa para el pulsador
    err = R_ICU_ExternalIrqOpen(&g_external_irq0_ctrl, &g_external_irq0_cfg);
    assert(FSP_SUCCESS == err);

    // Establecer la función de callback para la interrupción
    err = R_ICU_ExternalIrqCallbackSet(&g_external_irq0_ctrl, Btn_interruption, NULL, NULL);
    assert(FSP_SUCCESS == err);
}

// Función de callback para la interrupción del pulsador
void Btn_interruption(external_irq_callback_args_t *p_args) {
    // Comprobar si la interrupción proviene del canal configurado
    if (p_args->channel == g_external_irq0_cfg.channel) {
        system_on = true; // Cambiar el estado del sistema a "encendido"
    }
}

// Función para mostrar "SYSTEM ON" en el LCD
void mostrarSystemOn() {
    // Configuración de los arrays para mostrar el mensaje en el LCD
    m1[0x00] = 0x53; // 'S'
    m1[0x01] = 0x59; // 'Y'
    m1[0x02] = 0x53; // 'S'
    m1[0x03] = 0x54; // 'T'
    m1[0x04] = 0x45; // 'E'
    m1[0x05] = 0x4D; // 'M'
    m1[0x06] = 0x4F; // 'O'
    m1[0x07] = 0x4E; // 'N'

    m2[0x00] = 0x40;
    // El resto del array m2 se mantiene sin cambios

    // Llamada a la función para escribir en el LCD
    write_LCD(f1, m1);
    write_LCD(f2, m2);
}

// Función para mostrar un valor en el LCD
void DisplayLCD(uint16_t value, uint8_t m1[]) {
    // Conversión del valor a cadena y luego a caracteres ASCII
    char str[100];
    char numero_char;
    unsigned char ValorAsci1, ValorAsci2, ValorAsci3, ValorAsci4, ValorAsci5;

    sprintf(str, "%i", value);

    // Conversión de cada dígito a su representación ASCII
    numero_char = str[0];
    ValorAsci1 = (unsigned char)numero_char;

    numero_char = str[1];
    ValorAsci2 = (unsigned char)numero_char;

    numero_char = str[2];
    ValorAsci3 = (unsigned char)numero_char;

    numero_char = str[3];
    ValorAsci4 = (unsigned char)numero_char;

    numero_char = str[4];
    ValorAsci5 = (unsigned char)numero_char;

    // Configuración del array para mostrar los valores en el LCD
    m1[0x00] = 0x40;
    m1[0x01] = ValorAsci1;
    m1[0x02] = ValorAsci2;
    m1[0x03] = ValorAsci3;
    m1[0x04] = ValorAsci4;
    m1[0x05] = ValorAsci5;
    m1[0x06] = 0x80;
    m1[0x07] = 0x80;
}

// Función para mostrar una alerta en el LCD
void DisplayLCDAlerta(int nivel, uint8_t m1[]) {
    // Si el nivel es 4, se muestra una alerta y se hace parpadear el LED
    if (nivel == 4) {
        blink_led(); // Hacer parpadear el LED

        // Configuración del array para mostrar "PELIGRO" en el LCD
        m1[0x00] = 0x40;
        m1[0x01] = 0x50; // 'P'
        m1[0x02] = 0x45; // 'E'
        m1[0x03] = 0x4C; // 'L'
        m1[0x04] = 0x49; // 'I'
        m1[0x05] = 0x47; // 'G'
        m1[0x06] = 0x52; // 'R'
        m1[0x07] = 0x4F; // 'O


    } else {
        m1[0x00] = 0x40;
        m1[0x01] = 0x80;
        m1[0x02] = 0x80;
        m1[0x03] = 0x80;
        m1[0x04] = 0x80;
        m1[0x05] = 0x80;
        m1[0x06] = 0x80;
        m1[0x07] = 0x80;
    }
}

// Determina el nivel de velocidad basado en la mediana
int nivel_velocidad(uint16_t mediana) {
    // Umbrales de velocidad
    const uint16_t menor1 = 1000;
    const uint16_t menor2 = 2600;
    const uint16_t menor3 = 10000;

    // Devuelve el nivel de velocidad según los umbrales
    if (mediana < menor1) {
        return 1;
    } else if (mediana < menor2) {
        return 2;
    } else if (mediana < menor3) {
        return 3;
    } else {
        return 4;
    }
}

// Función de callback para el timer
void timer_callback(timer_callback_args_t *p_args) {
    // Verifica si es el evento de finalización del ciclo del timer
    if (TIMER_EVENT_CYCLE_END == p_args->event) {
        // Inicia la lectura del ADC y espera a que se complete
        ADCStartScan();
        ADCWaitConversion();

        // Lee el resultado del ADC
        uint16_t adc_result = ReadADC(ADC_CHANNEL_4);

        // Actualiza el filtro y calcula la mediana
        actualizarFiltro(adc_result);
        uint16_t mediana = calcularMediana();

        // Determina el nivel de velocidad
        int nivel = nivel_velocidad(adc_result);
        if (nivel == 4) {
            // Muestra la mediana y la alerta en el LCD si el nivel es 4
            DisplayLCD(mediana, m1);
            DisplayLCDAlerta(nivel, m2);
        } else {
            // Muestra "System On" en el LCD si el nivel no es 4
            mostrarSystemOn();
        }
    }
}

// Función de entrada principal del programa
void hal_entry(void) {
    fsp_err_t err = FSP_SUCCESS;
    // Inicializa y comienza el timer
    err = R_GPT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    assert(FSP_SUCCESS == err);
    (void) R_GPT_Start(&g_timer0_ctrl);

    // Inicializa el ADC y el I2C, luego inicializa el LCD
    ADCInit();
    fsp_err_t i2c = init_i2c();
    clear_i2c();
    initialice_LCD();

    // Inicializa y habilita el ICU, maneja errores
    err = icu_init();
    if (FSP_SUCCESS != err) {
        printf("Error en la inicializacion del driver");
    }

    err = icu_enable();
    if (FSP_SUCCESS != err) {
        icu_deinit();
        while(1); // Bucle infinito en caso de error
    }

    // Inicializa el LED y el pulsador
    init_led();
    init_pulsador();

    // Espera hasta que el sistema se active (por el pulsador)
    while (!system_on) { }

    // Muestra "System On" en el LCD
    mostrarSystemOn();
    // Bucle infinito para actualizar constantemente el LCD
    while (1) {
        write_LCD(f1, m1);
        write_LCD(f2, m2);
    }

    // Código específico para proyectos TrustZone Secure
#if BSP_TZ_SECURE_BUILD
    /* Entra en código no seguro */
    R_BSP_NonSecureEnter();
#endif
}

// Inicializa el módulo ICU
fsp_err_t icu_init(void) {
    fsp_err_t err = FSP_SUCCESS;

    /* Abre el módulo ICU */
    err = R_ICU_ExternalIrqOpen(&g_external_irq0_ctrl, &g_external_irq0_cfg);
    if (FSP_SUCCESS != err) {
        /* Manejo de error si falla la apertura de ICU */
        //APP_ERR_PRINT("\r\n**R_ICU_ExternalIrqOpen API FAILED**\r\n");
    }
    return err;
}

// Habilita el módulo ICU
fsp_err_t icu_enable(void) {
    fsp_err_t err = FSP_SUCCESS;

    /* Habilita el módulo ICU */
    err = R_ICU_ExternalIrqEnable(&g_external_irq0_ctrl);

    if (FSP_SUCCESS != err) {
        /* Manejo de error si falla la habilitación de ICU */
        //APP_ERR_PRINT("\r\n**R_ICU_ExternalIrqEnable API FAILED**\r\n");
    }
    return err;
}

// Deshabilita y cierra el módulo ICU
void icu_deinit(void) {
    fsp_err_t err = FSP_SUCCESS;

    /* Cierra el módulo ICU */
    err = R_ICU_ExternalIrqClose(&g_external_irq0_ctrl);
    if (FSP_SUCCESS != err) {
        /* Manejo de error si falla el cierre de ICU */
        //APP_ERR_PRINT("\r\n**R_ICU_ExternalIrqClose API FAILED**\r\n");
    }
}



/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open (&g_ioport_ctrl, g_ioport.p_cfg);
    }
}

#if BSP_TZ_SECURE_BUILD

BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
#endif
