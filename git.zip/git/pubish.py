import serial
import time
import csv
import json
import paho.mqtt.publish as publish
from datetime import datetime

uart_baudrate = 115200
try:
    uart_serial = serial.Serial('COM10', uart_baudrate, timeout=10, 
                                parity=serial.PARITY_NONE, 
                                stopbits=serial.STOPBITS_ONE, 
                                bytesize=serial.EIGHTBITS)
except serial.SerialException as e:
    print(f'Error al abrir puerto serial: {e}')
    exit(1)

topic = "pot"
hostname = "LAPTOP-EM4849EG"

def get_current_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def write_to_csv(data):
    try:
        with open('C:\\Users\\Hezitzaile\\Desktop\\IbanAitor_Trabajo.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([data, get_current_timestamp()])
    except IOError as e:
        print(f'Error al escribir en el archivo CSV: {e}')

def publish_message(mensaje):
    try:
        mensaje_json = json.dumps({"timestamp": get_current_timestamp(), "value": mensaje})
        publish.single(topic=topic, payload=mensaje_json, qos=1, hostname=hostname)
        print("Mensaje publicado vía MQTT: " + mensaje_json)
    except Exception as e:
        print(f'Error al publicar mensaje: {e}')

try:
    if uart_serial.is_open:
        while True:
            try:
                size = uart_serial.inWaiting()
                if size:
                    data = uart_serial.read(size)
                    try:
                        received_data_string = data.decode('utf-8')
                    except UnicodeDecodeError:
                        print('Error de decodificación')
                        continue
                    print(received_data_string)
                    write_to_csv(received_data_string)
                    publish_message(received_data_string)  
                else:
                    print('no data')
                    time.sleep(1)
            except serial.SerialException as e:
                print(f'Error de comunicación serial: {e}')
                break
    else:
        print('Puerto serie no abierto')
finally:
    uart_serial.close()
    print('Puerto serial cerrado')
