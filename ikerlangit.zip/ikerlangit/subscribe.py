import paho.mqtt.client as mqtt
import json

topic = "pot"


def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))

    client.subscribe(topic)


def on_message(client, userdata, msg):
    msg.payload = msg.payload.decode("utf-8")
    mensaje_recibido = msg.payload
    print("Mensaje recibido " + mensaje_recibido)

    mensaje_recibido_json = json.loads(msg.payload)
    timestamp = mensaje_recibido_json["timestamp"]
    print(timestamp)
    var_pot = mensaje_recibido_json["value"]
    print(var_pot)


client = mqtt.Client()

client.on_connect = on_connect
client.on_message = on_message

hostname = "raspberrypi"
client.connect(hostname, 1883, 60)
client.loop_forever()
