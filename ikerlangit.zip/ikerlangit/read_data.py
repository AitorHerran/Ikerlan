#read data

import serial
import time
import csv
import json
import paho.mqtt.publish as publish
from datetime import datetime

uart_baudrate = 115200
uart_serial = serial.Serial('/dev/ttyUSB0', uart_baudrate, timeout=10,
                            parity=serial.PARITY_NONE,
                            stopbits=serial.STOPBITS_ONE,
                            bytesize=serial.EIGHTBITS)

topic = "pot"
hostname = "raspberrypi"

def current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_to_csv(data):
    with open('IbanAitor_Trabajo.csv', 'a', newline='') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow([data, current_time()])

def send_mqtt(data):
    json_message = json.dumps({"timestamp": current_time(), "value": data})
    publish.single(topic=topic, payload=json_message, qos=1, hostname=hostname)
    print("Mensaje publicado vía MQTT: " + json_message)

if uart_serial.is_open:
    while True:
        available_data = uart_serial.inWaiting()
        if available_data:
            data = uart_serial.read(available_data)
            data_str = data.decode('utf-8')
            print(data_str)
            log_to_csv(data_str)
            send_mqtt(data_str)
        else:
           # print('No hay datos')
            time.sleep(1)
else:
    print('Puerto serie no está abierto')