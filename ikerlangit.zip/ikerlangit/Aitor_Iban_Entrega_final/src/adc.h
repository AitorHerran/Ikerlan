#ifndef LCD_I2C_H
#define LCD_I2C_H

#include "hal_data.h"

// Declaración de funciones para el manejo del ADC (Convertidor Analógico a Digital)

// Inicializa el ADC.
void ADCInit(void);

// Comienza la conversión del ADC.
void ADCStartScan(void);

// Espera hasta que se complete la conversión del ADC.
void ADCWaitConversion(void);

// Lee el valor convertido del ADC para un canal especificado.
uint16_t ReadADC(adc_channel_t Achan);

// Función de inicialización del ADC, llamada internamente.
static fsp_err_t ADC_Initialize(void);

#endif // LCD_I2C_H
