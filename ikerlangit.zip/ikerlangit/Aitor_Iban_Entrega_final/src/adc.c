#include "hal_data.h"

// Function to initialize the ADC
void ADCInit(void) {
    fsp_err_t err = FSP_SUCCESS;

    // Initialize ADC
    err = R_ADC_Open(&g_adc_ctrl, &g_adc_cfg);
    assert(FSP_SUCCESS == err);
    err = R_ADC_ScanCfg(&g_adc_ctrl, &g_adc_channel_cfg);
    assert(FSP_SUCCESS == err);
}

// Function to start ADC conversion
void ADCStartScan(void) {
    // In software trigger mode, start a scan by calling R_ADC_ScanStart().
    // In other modes, enable external triggers by calling R_ADC_ScanStart().
    R_ADC_ScanStart(&g_adc_ctrl);
}

// Function to wait for ADC conversion completion
int ADCWaitConversion(void) {
    // Wait for the conversion to complete.
    adc_status_t status;
    R_ADC_StatusGet(&g_adc_ctrl, &status);

    if (status.state == ADC_STATE_SCAN_IN_PROGRESS) {
        return 0;  // Returns 0 if conversion is in progress.
    }
    return 1;  // Returns 1 if conversion has completed.
}

// Function to read the converted ADC value
uint16_t ReadADC(adc_channel_t Achan) {
    fsp_err_t err = FSP_SUCCESS;
    uint16_t channel4_conversion_result;

    // Read the value from the potentiometer connected at the specified channel.
    err = R_ADC_Read(&g_adc_ctrl, Achan, &channel4_conversion_result);
    assert(FSP_SUCCESS == err);

    return channel4_conversion_result;
}

// ADC initialization function (called by ADC_Initialize)
static fsp_err_t ADC_Initialize(void) {
    fsp_err_t fsp_err = FSP_SUCCESS;

    // Open the ADC controller
    fsp_err = R_ADC_Open(&g_adc_ctrl, &g_adc_cfg);
    if (FSP_SUCCESS != fsp_err)
        return fsp_err;

    // Configure ADC scanning
    fsp_err = R_ADC_ScanCfg(&g_adc_ctrl, &g_adc_channel_cfg);
    if (FSP_SUCCESS != fsp_err)
        return fsp_err;

    // Start ADC scanning
    fsp_err = R_ADC_ScanStart(&g_adc_ctrl);
    if (FSP_SUCCESS != fsp_err)
        return fsp_err;

    return fsp_err;
}


